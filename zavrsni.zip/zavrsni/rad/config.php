<?php

define("DB","bookstore");
define("DBHOST","localhost");
define("DBUSER","root");
define("DBPASS","");
?>





ovo je vasa pretraga odgledati izmedju 45 i 53 i u chekpoint 7

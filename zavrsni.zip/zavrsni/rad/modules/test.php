<div id="test">
<img src="images/baner3.jpg" alt="vesti" width="500px" height="200px">
</div>
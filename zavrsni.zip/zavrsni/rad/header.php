	<div class="menu">
   <div class="navbar-header">
			<a href="?page=2">VASA KNJIZARA</a>
		</div>
   <div class="container" id="inputpolje">
	<div class="row">
        <div class="col-md-6" id="iznadinputa">
    		<h4>Pronadji knjigu</h4>
            <div id="custom-search-input">
                <div class="input-group col-md-12">
                    <input type="text" class="form-control input-lg" placeholder="Buscar" />
                    <span class="input-group-btn">
                        <button class="btn btn-info btn-lg" type="button">
                            <i class="glyphicon glyphicon-search"></i>
                        </button>
                    </span>
                </div>
            </div>
        </div>
	</div>
</div>
    <div class="container-fluid">
		
		<div>
			<ul class="nav navbar-nav navbar-right">
			    <li><a href="?page=3"><i class="fa fa-shopping-cart" aria-hidden="true">   Moja korpa</i></a></li>
				<li><a href="#" ><span class="glyphicon glyphicon-user"></span> Registruj se</a></li>
				<li><a href="admin/index.html"><span class="glyphicon glyphicon-log-in"></span> Uloguj se</a></li>
			</ul>
		</div>
	</div>
</div>
<div class="baner" id="prvibaner">
	<a href="http://www.laguna.rs/"><img src="images/baner1.jpg" alt="reklama"></a>
</div>
<div class="baner" id="drugibaner">
	<img src="images/baner2.jpg" alt="bilanovic">
</div>
